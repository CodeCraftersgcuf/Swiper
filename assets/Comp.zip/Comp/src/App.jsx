import React from 'react';
import { Routes, Route, Link } from 'react-router-dom'; // No need to import BrowserRouter here
import Card1 from './pages/Card1';
import Card2 from './pages/Card2';

function App() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <nav className="space-x-4">
        <Link
          to="/card1"
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Open Card 1
        </Link>
        <Link
          to="/card2"
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Open Card 2
        </Link>
      </nav>
      <Routes>
        <Route path="/card1" element={<Card1 />} />
        <Route path="/card2" element={<Card2 />} />
      </Routes>
    </div>
  );
}

export default App;
