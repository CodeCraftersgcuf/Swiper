import React, { useState } from 'react';

const Card2 = () => {
  const [isOpen, setIsOpen] = useState(true);

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleOutsideClick = (e) => {
    if (e.target.classList.contains('modal-backdrop')) {
      handleClose();
    }
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop"
          onClick={handleOutsideClick}
        >
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md mx-4 sm:mx-0 p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">UNLOCK</h2>
              <button
                className="text-gray-500 hover:text-gray-700 focus:outline-none"
                onClick={handleClose}
              >
                <svg
                  className="h-6 w-6"
                  fill="none"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <p className="text-gray-700 mb-4">10% OFF</p>
            <form className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-gray-700 font-bold mb-2">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  className="border border-gray-400 p-2 rounded-lg w-full"
                  placeholder="liam@acme.com"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-gray-700 font-bold mb-2">
                  Phone Number
                </label>
                <input
                  id="phone"
                  type="tel"
                  className="border border-gray-400 p-2 rounded-lg w-full"
                  placeholder="(123) 123-1234"
                />
              </div>
              <button
                type="submit"
                className="bg-black text-white py-2 px-4 rounded-lg hover:bg-gray-800 focus:outline-none"
              >
                Subscribe
              </button>
            </form>
            <p className="text-gray-500 text-xs mt-4">
              By signing up via text you agree to receive recurring automated marketing messages and recurring cart reminders at the phone number provided. Consent is not a condition of purchase. Reply STOP to unsubscribe, HELP for help. Msg & data rates may apply. View Privacy & Terms of Service.
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default Card2;