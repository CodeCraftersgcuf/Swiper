import React, { useState } from 'react';

const Card1 = () => {
  const [isOpen, setIsOpen] = useState(true);

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleOutsideClick = (e) => {
    if (e.target.classList.contains('modal-backdrop')) {
      handleClose();
    }
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop"
          onClick={handleOutsideClick}
        >
          <div className="bg-white rounded-lg shadow-md w-full max-w-md mx-4 sm:mx-0 p-8">
            <div className="px-6 py-4">
              <div className="flex justify-center">
                <h1 className="text-4xl font-bold">
                  <span className="text-black">Pang</span>
                  <span className="text-yellow-500">3</span>
                  <span className="text-black">a</span>
                </h1>
              </div>
              <h2 className="text-3xl font-bold text-center mt-6">Welcome to our site</h2>
              <p className="text-gray-600 text-center mt-4">Please, verify your age to enter</p>
              <div className="flex justify-center mt-6">
                <button className=" text-black font-bold py-2 px-6 rounded-full border border-black ">
                  I am 18 or older
                </button>
              </div>
              <p className="text-gray-600  text-xs mt-4">
                By entering this site you are agreeing to the Terms of Use and Privacy Policy.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Card1;
